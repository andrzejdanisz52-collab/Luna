# Luna PRO 0.5 - no custom shrinking rules required for debug build.
