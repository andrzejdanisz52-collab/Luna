package pl.lunapro.luna

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class LunaVoiceService : Service(), RecognitionListener {
    companion object {
        const val ACTION_START = "pl.lunapro.luna.START"
        const val ACTION_SLEEP = "pl.lunapro.luna.SLEEP"
        private const val CHANNEL_ID = "luna_voice"
        private const val NOTIFICATION_ID = 5
        private const val RESTART_DELAY_MS = 500L
        private const val SLEEP_STOP_DELAY_MS = 1400L
    }
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var sleeping = true
    private var shuttingDown = false
    private var voiceIdEnabled = true
    private var voiceIdPassed = false
    private val voiceId by lazy { VoiceIdManager(this) }

    override fun onCreate() {
        super.onCreate(); createChannel()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("pl", "PL") }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(this)
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) { ACTION_START -> startLuna(); ACTION_SLEEP -> sleepLuna() }
        return START_STICKY
    }
    private fun startLuna() {
        shuttingDown=false; sleeping=false
        val notification=Notification.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(getString(R.string.app_name)).setContentText("Luna nasłuchuje słowa „Luna”").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(NOTIFICATION_ID, notification)
        startListening()
    }
    private fun startListening() {
        if (sleeping || shuttingDown) return
        val r=recognizer ?: return
        try {
            r.cancel()
            val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pl-PL"); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3) }
            r.startListening(i)
        } catch (_: Exception) { restartListening() }
    }
    override fun onResults(results: Bundle?) {
        if (sleeping || shuttingDown) return
        val spoken=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale("pl","PL"))?.trim().orEmpty()
        processSpeech(spoken)
    }
    private fun processSpeech(spoken:String) {
        if (!spoken.contains("luna")) { restartListening(); return }
        if (voiceIdEnabled && !voiceIdPassed) {
            requestVoiceVerification()
            return
        }
        val command=spoken.substringAfter("luna").trim(' ', ',', '.', ':', ';', '-', '—')
        when {
            command.isBlank() -> speak("Słucham.")
            command=="śpij" || command=="spij" || command.startsWith("śpij ") || command.startsWith("spij ") -> sleepLuna()
            command.contains("kim jesteś") || command.contains("kim jestes") -> speak("Jestem Luna.")
            command.contains("cześć") || command.contains("czesc") -> speak("Cześć, Andrzej.")
            else -> speak("Usłyszałam: $command")
        }
        if (!sleeping) restartListening()
    }

    private fun requestVoiceVerification() {
        if (!voiceId.isEnrolled()) {
            speak("Nie mam jeszcze profilu głosu Andrzeja. Otwórz aplikację i nagraj profil głosu.")
            restartListening()
            return
        }
        speak("Powiedz krótko: Andrzej.")
        handler.postDelayed({
            voiceIdPassed = voiceId.verify(2)
            if (!voiceIdPassed) {
                speak("Nie jesteś Andrzejem.")
                restartListening()
            } else {
                speak("Rozpoznano Andrzeja.")
                handler.postDelayed({ startListening() }, 700L)
            }
        }, 900L)
    }
    private fun sleepLuna() {
        if (shuttingDown) return
        sleeping=true; shuttingDown=true; recognizer?.cancel(); speak("Śpię.")
        handler.postDelayed({ stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }, SLEEP_STOP_DELAY_MS)
    }
    private fun speak(text:String) { tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"LUNA_${System.currentTimeMillis()}") }
    private fun restartListening() { if (sleeping || shuttingDown) return; handler.removeCallbacksAndMessages(null); handler.postDelayed({ startListening() },RESTART_DELAY_MS) }
    private fun createChannel() { getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID,getString(R.string.notification_channel_name),NotificationManager.IMPORTANCE_LOW).apply { description=getString(R.string.notification_channel_description) }) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); recognizer?.cancel(); recognizer?.destroy(); recognizer=null; tts?.stop(); tts?.shutdown(); tts=null; super.onDestroy() }
    override fun onBind(intent:Intent?)=null
    override fun onReadyForSpeech(params:Bundle?){}; override fun onBeginningOfSpeech(){}; override fun onRmsChanged(rmsdB:Float){}; override fun onBufferReceived(buffer:ByteArray?){}; override fun onEndOfSpeech(){}; override fun onError(error:Int){if(!sleeping&&!shuttingDown)restartListening()}; override fun onPartialResults(partialResults:Bundle?){}; override fun onEvent(eventType:Int,params:Bundle?){ }
}
