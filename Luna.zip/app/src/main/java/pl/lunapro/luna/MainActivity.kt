package pl.lunapro.luna

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val requestCode = 100
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(0xFF10131A.toInt())
        }
        val title = TextView(this).apply {
            text = "Luna"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
        }
        status = TextView(this).apply {
            text = "Gotowa. Nadaj uprawnienie mikrofonu i uruchom Lunę."
            textSize = 17f
            setTextColor(0xFFD0D5DD.toInt())
            setPadding(0, 32, 0, 32)
        }
        val start = Button(this).apply { text = "URUCHOM LUNĘ" }
        val stop = Button(this).apply { text = "UŚPIJ LUNĘ" }
        val enroll = Button(this).apply { text = "NAGRAJ PROFIL GŁOSU ANDRZEJA" }
        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(enroll)
        setContentView(root)

        start.setOnClickListener { startLuna() }
        stop.setOnClickListener { stopLuna() }
        enroll.setOnClickListener { enrollVoice() }
        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.RECORD_AUDIO
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions.toTypedArray(), requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            status.text = if (ok) "Mikrofon gotowy. Możesz uruchomić Lunę." else "Bez dostępu do mikrofonu Luna nie może słuchać."
        }
    }


    private fun enrollVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionsIfNeeded(); return
        }
        status.text = "Nagrywam profil głosu. Przez 3 sekundy mów naturalnie."
        Thread {
            val ok = VoiceIdManager(this).enroll(3)
            runOnUiThread {
                status.text = if (ok) "Profil głosu Andrzeja zapisany w telefonie." else "Nie udało się nagrać profilu głosu."
                Toast.makeText(this, if (ok) "Profil głosu zapisany" else "Błąd nagrania", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun startLuna() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionsIfNeeded()
            status.text = "Najpierw zezwól Lunie na mikrofon."
            return
        }
        val intent = Intent(this, LunaVoiceService::class.java).setAction(LunaVoiceService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        status.text = "Luna słucha. Powiedz: Luna ..."
    }

    private fun stopLuna() {
        val intent = Intent(this, LunaVoiceService::class.java).setAction(LunaVoiceService.ACTION_SLEEP)
        ContextCompat.startForegroundService(this, intent)
        status.text = "Luna śpi."
    }
}
