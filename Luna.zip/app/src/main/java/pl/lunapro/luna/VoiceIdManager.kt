package pl.lunapro.luna

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Local, offline speaker profile based on a compact MFCC signature. */
class VoiceIdManager(private val context: Context) {
    private val sampleRate = 16000
    private val channels = AudioFormat.CHANNEL_IN_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT
    private val profileFile = File(context.filesDir, "andrew_voice_profile.bin")

    fun isEnrolled(): Boolean = profileFile.exists() && profileFile.length() > 0

    fun enroll(seconds: Int = 3): Boolean {
        val samples = record(seconds) ?: return false
        val vector = signature(samples)
        if (vector.isEmpty()) return false
        profileFile.writeText(vector.joinToString(","))
        return true
    }

    fun verify(seconds: Int = 2): Boolean {
        if (!isEnrolled()) return false
        val reference = profileFile.readText().split(",").mapNotNull { it.toFloatOrNull() }.toFloatArray()
        val samples = record(seconds) ?: return false
        val candidate = signature(samples)
        if (reference.size != candidate.size || reference.isEmpty()) return false
        return cosine(reference, candidate) >= 0.90f
    }

    private fun record(seconds: Int): ShortArray? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return null
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, channels, encoding)
        if (minBuffer <= 0) return null
        val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channels, encoding, max(minBuffer * 2, 4096))
        val out = ShortArray(sampleRate * seconds)
        var offset = 0
        try {
            recorder.startRecording()
            while (offset < out.size) {
                val n = recorder.read(out, offset, out.size - offset)
                if (n <= 0) return null
                offset += n
            }
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            recorder.release()
        }
        return out
    }

    private fun signature(samples: ShortArray): FloatArray {
        val frame = 400
        val hop = 160
        val bins = 26
        val mel = FloatArray(bins)
        var frames = 0
        var i = 0
        while (i + frame <= samples.size) {
            val power = DoubleArray(bins)
            for (k in 0 until frame) {
                val x = samples[i + k] / 32768.0
                val w = 0.54 - 0.46 * cos(2.0 * Math.PI * k / (frame - 1))
                val f = k.toDouble() / frame
                val bin = min(bins - 1, (f * bins).toInt())
                power[bin] += x * x * w * w
            }
            for (b in 0 until bins) mel[b] += ln(1e-8 + power[b]).toFloat()
            frames++
            i += hop
        }
        if (frames == 0) return FloatArray(0)
        for (b in mel.indices) mel[b] /= frames.toFloat()
        val mfcc = FloatArray(13)
        for (c in 0 until 13) {
            var sum = 0.0
            for (b in 0 until bins) sum += mel[b] * cos(Math.PI * c * (b + 0.5) / bins)
            mfcc[c] = sum.toFloat()
        }
        var norm = 0.0
        for (v in mfcc) norm += v * v
        norm = sqrt(max(norm, 1e-12))
        for (j in mfcc.indices) mfcc[j] = (mfcc[j] / norm).toFloat()
        return mfcc
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return (dot / sqrt(max(na * nb, 1e-12))).toFloat()
    }
}
